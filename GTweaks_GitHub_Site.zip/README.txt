GTweaks GitHub Pages starter package

Replace your current index.html with this one, and add GTweaks-Optimize.ps1 to the repository.
The site includes clickable navigation, product filters, product detail modals, FAQ accordions,
mobile navigation, a GTweaks G favicon/PFP, and a script preview/copy button.

Starter catalog:
$10 GTweaks Starter
$15 GTweaks Network
$15 GTweaks Monitor
$25 GTweaks Performance
$40 GTweaks Pro
$55 GTweaks Complete

Checkout is not connected. Replace the placeholder checkout action with your real payment URL.
Do not advertise guaranteed FPS/ping gains; results vary by PC.
