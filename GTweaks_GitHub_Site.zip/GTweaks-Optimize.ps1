# GTweaks conservative Windows starter script
# Review this file before running it.
# Run PowerShell as Administrator.

$ErrorActionPreference = "Stop"

Write-Host "GTweaks - creating a restore point..." -ForegroundColor White
try {
    Enable-ComputerRestore -Drive "$env:SystemDrive\"
    Checkpoint-Computer -Description "GTweaks Before Optimization" -RestorePointType "MODIFY_SETTINGS"
} catch {
    Write-Warning "Restore point could not be created automatically: $($_.Exception.Message)"
}

Write-Host "Setting Windows Game Mode..." -ForegroundColor White
New-Item -Path "HKCU:\Software\Microsoft\GameBar" -Force | Out-Null
Set-ItemProperty -Path "HKCU:\Software\Microsoft\GameBar" -Name "AutoGameModeEnabled" -Type DWord -Value 1

Write-Host "Setting a high-performance power plan when available..." -ForegroundColor White
$high = (powercfg /L | Select-String -Pattern "High performance")
if ($high) {
    $guid = [regex]::Match($high.ToString(), "[0-9a-fA-F-]{36}").Value
    if ($guid) { powercfg /S $guid }
}

Write-Host "GTweaks starter changes complete." -ForegroundColor Green
Write-Host "Restart Windows if a setting does not take effect."
